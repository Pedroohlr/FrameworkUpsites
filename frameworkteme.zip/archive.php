<?php
/**
 * Archive Template - Blog
 * 
 * Template para exibir a lista de posts do blog
 * 
 * @package FrameworkTema
 */

get_header(); ?>

<main>
    
</main>

<?php get_footer(); ?>