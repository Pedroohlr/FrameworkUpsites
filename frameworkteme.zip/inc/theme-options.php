<?php
/**
 * Theme Options
 * 
 * Página de configurações do tema no admin
 * Permite configurar opções globais sem precisar editar código
 * 
 * @package FrameworkTema
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Adiciona página de opções do tema no admin
 */
function frameworktema_add_theme_options_page() {
    add_menu_page(
        'Opções do Tema',           // Título da página
        'Opções FrameworkTema',         // Título no menu
        'manage_options',           // Capacidade necessária
        'frameworktema-options',        // Slug da página
        'frameworktema_render_options_page', // Função de callback
        'dashicons-admin-customizer',    // Ícone
        61                          // Posição no menu
    );
}
add_action('admin_menu', 'frameworktema_add_theme_options_page');

/**
 * Registra as configurações
 */
function frameworktema_register_settings() {
    // Seção: Informações de Contato
    register_setting('frameworktema_options', 'frameworktema_phone');
    register_setting('frameworktema_options', 'frameworktema_email');
    register_setting('frameworktema_options', 'frameworktema_address');
    register_setting('frameworktema_options', 'frameworktema_whatsapp');
    
    // Seção: Redes Sociais
    register_setting('frameworktema_options', 'frameworktema_facebook');
    register_setting('frameworktema_options', 'frameworktema_instagram');
    register_setting('frameworktema_options', 'frameworktema_linkedin');
    register_setting('frameworktema_options', 'frameworktema_twitter');
    register_setting('frameworktema_options', 'frameworktema_youtube');
    
    // Seção: Scripts
    register_setting('frameworktema_options', 'frameworktema_google_analytics');
    register_setting('frameworktema_options', 'frameworktema_facebook_pixel');
    register_setting('frameworktema_options', 'frameworktema_header_scripts');
    register_setting('frameworktema_options', 'frameworktema_footer_scripts');
    
    // Seção: Performance
    register_setting('frameworktema_options', 'frameworktema_disable_emojis');
    register_setting('frameworktema_options', 'frameworktema_disable_embeds');
    register_setting('frameworktema_options', 'frameworktema_lazy_load');
}
add_action('admin_init', 'frameworktema_register_settings');

/**
 * Renderiza a página de opções
 */
function frameworktema_render_options_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Salva as configurações
    if (isset($_GET['settings-updated'])) {
        add_settings_error(
            'frameworktema_messages',
            'frameworktema_message',
            'Configurações salvas com sucesso!',
            'updated'
        );
    }
    
    settings_errors('frameworktema_messages');
    ?>
    
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <form method="post" action="options.php">
            <?php settings_fields('frameworktema_options'); ?>
            
            <div class="nav-tab-wrapper">
                <a href="#tab-contact" class="nav-tab nav-tab-active">Contato</a>
                <a href="#tab-social" class="nav-tab">Redes Sociais</a>
                <a href="#tab-scripts" class="nav-tab">Scripts</a>
                <a href="#tab-performance" class="nav-tab">Performance</a>
            </div>
            
            <!-- Tab: Contato -->
            <div id="tab-contact" class="tab-content" style="display: block;">
                <h2>Informações de Contato</h2>
                <p>Configure as informações de contato que aparecem no site.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="frameworktema_phone">Telefone</label></th>
                        <td>
                            <input type="text" id="frameworktema_phone" name="frameworktema_phone" 
                                   value="<?php echo esc_attr(get_option('frameworktema_phone')); ?>" 
                                   class="regular-text">
                            <p class="description">Ex: (11) 1234-5678</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_whatsapp">WhatsApp</label></th>
                        <td>
                            <input type="text" id="frameworktema_whatsapp" name="frameworktema_whatsapp" 
                                   value="<?php echo esc_attr(get_option('frameworktema_whatsapp')); ?>" 
                                   class="regular-text">
                            <p class="description">Ex: 5511912345678 (com DDI + DDD, sem espaços)</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_email">Email</label></th>
                        <td>
                            <input type="email" id="frameworktema_email" name="frameworktema_email" 
                                   value="<?php echo esc_attr(get_option('frameworktema_email')); ?>" 
                                   class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_address">Endereço</label></th>
                        <td>
                            <textarea id="frameworktema_address" name="frameworktema_address" 
                                      rows="3" class="large-text"><?php echo esc_textarea(get_option('frameworktema_address')); ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Tab: Redes Sociais -->
            <div id="tab-social" class="tab-content" style="display: none;">
                <h2>Redes Sociais</h2>
                <p>Adicione os links das suas redes sociais.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="frameworktema_facebook">Facebook</label></th>
                        <td>
                            <input type="url" id="frameworktema_facebook" name="frameworktema_facebook" 
                                   value="<?php echo esc_url(get_option('frameworktema_facebook')); ?>" 
                                   class="regular-text" placeholder="https://facebook.com/sua-pagina">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_instagram">Instagram</label></th>
                        <td>
                            <input type="url" id="frameworktema_instagram" name="frameworktema_instagram" 
                                   value="<?php echo esc_url(get_option('frameworktema_instagram')); ?>" 
                                   class="regular-text" placeholder="https://instagram.com/seu-perfil">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_linkedin">LinkedIn</label></th>
                        <td>
                            <input type="url" id="frameworktema_linkedin" name="frameworktema_linkedin" 
                                   value="<?php echo esc_url(get_option('frameworktema_linkedin')); ?>" 
                                   class="regular-text" placeholder="https://linkedin.com/company/sua-empresa">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_twitter">Twitter / X</label></th>
                        <td>
                            <input type="url" id="frameworktema_twitter" name="frameworktema_twitter" 
                                   value="<?php echo esc_url(get_option('frameworktema_twitter')); ?>" 
                                   class="regular-text" placeholder="https://twitter.com/seu-perfil">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_youtube">YouTube</label></th>
                        <td>
                            <input type="url" id="frameworktema_youtube" name="frameworktema_youtube" 
                                   value="<?php echo esc_url(get_option('frameworktema_youtube')); ?>" 
                                   class="regular-text" placeholder="https://youtube.com/@seu-canal">
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Tab: Scripts -->
            <div id="tab-scripts" class="tab-content" style="display: none;">
                <h2>Scripts e Rastreamento</h2>
                <p>Adicione códigos de rastreamento e scripts personalizados.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="frameworktema_google_analytics">Google Analytics 4 ID</label></th>
                        <td>
                            <input type="text" id="frameworktema_google_analytics" name="frameworktema_google_analytics" 
                                   value="<?php echo esc_attr(get_option('frameworktema_google_analytics')); ?>" 
                                   class="regular-text" placeholder="G-XXXXXXXXXX">
                            <p class="description">Apenas o ID, ex: G-XXXXXXXXXX</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_facebook_pixel">Facebook Pixel ID</label></th>
                        <td>
                            <input type="text" id="frameworktema_facebook_pixel" name="frameworktema_facebook_pixel" 
                                   value="<?php echo esc_attr(get_option('frameworktema_facebook_pixel')); ?>" 
                                   class="regular-text" placeholder="123456789012345">
                            <p class="description">Apenas o ID numérico</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_header_scripts">Scripts no Header</label></th>
                        <td>
                            <textarea id="frameworktema_header_scripts" name="frameworktema_header_scripts" 
                                      rows="5" class="large-text code"><?php echo esc_textarea(get_option('frameworktema_header_scripts')); ?></textarea>
                            <p class="description">Códigos que serão inseridos antes do &lt;/head&gt;</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="frameworktema_footer_scripts">Scripts no Footer</label></th>
                        <td>
                            <textarea id="frameworktema_footer_scripts" name="frameworktema_footer_scripts" 
                                      rows="5" class="large-text code"><?php echo esc_textarea(get_option('frameworktema_footer_scripts')); ?></textarea>
                            <p class="description">Códigos que serão inseridos antes do &lt;/body&gt;</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Tab: Performance -->
            <div id="tab-performance" class="tab-content" style="display: none;">
                <h2>Otimizações de Performance</h2>
                <p>Ative otimizações para melhorar o desempenho do site.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Desativar Emojis</th>
                        <td>
                            <label>
                                <input type="checkbox" name="frameworktema_disable_emojis" value="1" 
                                       <?php checked(get_option('frameworktema_disable_emojis'), 1); ?>>
                                Remove scripts de emojis do WordPress (melhora performance)
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Desativar Embeds</th>
                        <td>
                            <label>
                                <input type="checkbox" name="frameworktema_disable_embeds" value="1" 
                                       <?php checked(get_option('frameworktema_disable_embeds'), 1); ?>>
                                Remove scripts de embed do WordPress
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Lazy Load de Imagens</th>
                        <td>
                            <label>
                                <input type="checkbox" name="frameworktema_lazy_load" value="1" 
                                       <?php checked(get_option('frameworktema_lazy_load'), 1); ?>>
                                Ativa carregamento lazy de imagens (nativo do navegador)
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
            
            <?php submit_button('Salvar Configurações'); ?>
        </form>
    </div>
    
    <style>
        .nav-tab-wrapper { margin-bottom: 20px; }
        .tab-content { 
            background: #fff; 
            padding: 20px; 
            border: 1px solid #ccd0d4;
            border-top: none;
        }
    </style>
    
    <script>
        jQuery(document).ready(function($) {
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                var target = $(this).attr('href');
                
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                $('.tab-content').hide();
                $(target).show();
            });
        });
    </script>
    
    <?php
}

/**
 * Helper functions para acessar as opções
 */
function frameworktema_get_option($option_name, $default = '') {
    $value = get_option('frameworktema_' . $option_name, $default);
    return !empty($value) ? $value : $default;
}

function frameworktema_get_phone() {
    return frameworktema_get_option('phone');
}

function frameworktema_get_whatsapp() {
    return frameworktema_get_option('whatsapp');
}

function frameworktema_get_email() {
    return frameworktema_get_option('email');
}

function frameworktema_get_address() {
    return frameworktema_get_option('address');
}

function frameworktema_get_social($network) {
    return frameworktema_get_option($network);
}

// Adiciona novos campos de opções
add_action('admin_init', function() {
    register_setting('frameworktema_options', 'frameworktema_footer_description');
    register_setting('frameworktema_options', 'frameworktema_contact_cta_title');
    register_setting('frameworktema_options', 'frameworktema_contact_cta_description');
    register_setting('frameworktema_options', 'frameworktema_contact_cta_button');
    register_setting('frameworktema_options', 'frameworktema_contact_cta_link');
    register_setting('frameworktema_options', 'frameworktema_site_tagline');
});
