<?php
/**
 * Helper Functions
 * 
 * Funções auxiliares úteis para usar em qualquer projeto
 * 
 * @package FrameworkTema
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Formata número de telefone
 */
function frameworktema_format_phone($phone) {
    if (empty($phone)) return '';
    
    // Remove tudo que não é número
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Formata baseado na quantidade de dígitos
    if (strlen($phone) == 11) {
        // (11) 91234-5678
        return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 5) . '-' . substr($phone, 7);
    } elseif (strlen($phone) == 10) {
        // (11) 1234-5678
        return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 4) . '-' . substr($phone, 6);
    }
    
    return $phone;
}

/**
 * Gera link do WhatsApp
 */
function frameworktema_whatsapp_link($number = '', $message = '') {
    if (empty($number)) {
        $number = frameworktema_get_whatsapp();
    }
    
    if (empty($number)) return '#';
    
    // Remove tudo que não é número
    $number = preg_replace('/[^0-9]/', '', $number);
    
    $link = 'https://wa.me/' . $number;
    
    if (!empty($message)) {
        $link .= '?text=' . urlencode($message);
    }
    
    return $link;
}

/**
 * Obtém URL de imagem otimizada
 */
function frameworktema_get_optimized_image($image_id, $size = 'full') {
    if (!$image_id) return '';
    
    $image = wp_get_attachment_image_src($image_id, $size);
    
    if (!$image) return '';
    
    return $image[0];
}

/**
 * Obtém imagem responsiva com srcset
 */
function frameworktema_get_responsive_image($image_id, $size = 'full', $class = '') {
    if (!$image_id) return '';
    
    return wp_get_attachment_image($image_id, $size, false, array(
        'class' => $class,
        'loading' => 'lazy',
    ));
}

/**
 * Limita texto por caracteres
 */
function frameworktema_limit_text($text, $limit = 100, $ending = '...') {
    if (mb_strlen($text) <= $limit) {
        return $text;
    }
    
    $text = mb_substr($text, 0, $limit);
    $text = mb_substr($text, 0, mb_strrpos($text, ' '));
    
    return $text . $ending;
}

/**
 * Limita texto por palavras
 */
function frameworktema_limit_words($text, $limit = 20, $ending = '...') {
    $words = explode(' ', $text);
    
    if (count($words) <= $limit) {
        return $text;
    }
    
    return implode(' ', array_slice($words, 0, $limit)) . $ending;
}

/**
 * Calcula tempo de leitura estimado
 */
function frameworktema_reading_time($content = '') {
    if (empty($content)) {
        $content = get_the_content();
    }
    
    $word_count = str_word_count(strip_tags($content));
    $minutes = ceil($word_count / 200); // 200 palavras por minuto
    
    if ($minutes == 1) {
        return '1 minuto de leitura';
    }
    
    return $minutes . ' minutos de leitura';
}

/**
 * Verifica se está em mobile
 */
function frameworktema_is_mobile() {
    return wp_is_mobile();
}

/**
 * Obtém URL de vídeo do YouTube pelo ID
 */
function frameworktema_youtube_embed($video_id, $autoplay = false) {
    $url = 'https://www.youtube.com/embed/' . $video_id;
    
    if ($autoplay) {
        $url .= '?autoplay=1&mute=1';
    }
    
    return $url;
}

/**
 * Obtém URL do Vimeo pelo ID
 */
function frameworktema_vimeo_embed($video_id, $autoplay = false) {
    $url = 'https://player.vimeo.com/video/' . $video_id;
    
    if ($autoplay) {
        $url .= '?autoplay=1&muted=1';
    }
    
    return $url;
}

/**
 * Formata preço em Real
 */
function frameworktema_format_price($price) {
    return 'R$ ' . number_format($price, 2, ',', '.');
}

/**
 * Sanitiza título para URL
 */
function frameworktema_sanitize_title($title) {
    return sanitize_title($title);
}

/**
 * Obtém primeiro parágrafo do conteúdo
 */
function frameworktema_get_first_paragraph($content = '') {
    if (empty($content)) {
        $content = get_the_content();
    }
    
    $content = apply_filters('the_content', $content);
    $paragraphs = explode('</p>', $content);
    
    if (!empty($paragraphs[0])) {
        return $paragraphs[0] . '</p>';
    }
    
    return '';
}

/**
 * Obtém cor contrastante (branco ou preto) baseado em uma cor
 */
function frameworktema_get_contrast_color($hex) {
    // Remove o # se existir
    $hex = str_replace('#', '', $hex);
    
    // Converte para RGB
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    // Calcula luminosidade
    $luminosity = (($r * 0.299) + ($g * 0.587) + ($b * 0.114)) / 255;
    
    return $luminosity > 0.5 ? '#000000' : '#FFFFFF';
}

/**
 * Verifica se uma URL é externa
 */
function frameworktema_is_external_url($url) {
    $site_url = parse_url(home_url());
    $url_parts = parse_url($url);
    
    if (!isset($url_parts['host'])) {
        return false;
    }
    
    return $url_parts['host'] !== $site_url['host'];
}

/**
 * Adiciona target="_blank" em links externos
 */
function frameworktema_external_link_attributes($url, $text = '') {
    if (frameworktema_is_external_url($url)) {
        return 'target="_blank" rel="noopener noreferrer"';
    }
    
    return '';
}

/**
 * Breadcrumbs
 */
function frameworktema_breadcrumbs() {
    if (is_front_page()) return;
    
    $separator = '<span class="mx-2">/</span>';
    $home = '<a href="' . home_url('/') . '" class="text-blue-600 hover:text-blue-800">Início</a>';
    
    echo '<nav class="breadcrumbs text-sm text-gray-600 mb-4">';
    echo $home . $separator;
    
    if (is_category() || is_single()) {
        if (is_single()) {
            $category = get_the_category();
            if ($category) {
                echo '<a href="' . get_category_link($category[0]->term_id) . '" class="text-blue-600 hover:text-blue-800">' . $category[0]->name . '</a>' . $separator;
            }
            echo '<span class="text-gray-900">' . get_the_title() . '</span>';
        } else {
            echo '<span class="text-gray-900">' . single_cat_title('', false) . '</span>';
        }
    } elseif (is_page()) {
        if ($post->post_parent) {
            $parent_id = $post->post_parent;
            $breadcrumbs = array();
            
            while ($parent_id) {
                $page = get_page($parent_id);
                $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '" class="text-blue-600 hover:text-blue-800">' . get_the_title($page->ID) . '</a>';
                $parent_id = $page->post_parent;
            }
            
            $breadcrumbs = array_reverse($breadcrumbs);
            foreach ($breadcrumbs as $crumb) {
                echo $crumb . $separator;
            }
        }
        
        echo '<span class="text-gray-900">' . get_the_title() . '</span>';
    } elseif (is_search()) {
        echo '<span class="text-gray-900">Pesquisa por: ' . get_search_query() . '</span>';
    } elseif (is_404()) {
        echo '<span class="text-gray-900">Página não encontrada</span>';
    }
    
    echo '</nav>';
}

/**
 * Share buttons sociais
 */
function frameworktema_social_share($title = 'Compartilhar:', $show_label = true) {
    $url = urlencode(get_permalink());
    $title_text = urlencode(get_the_title());
    
    $facebook = 'https://www.facebook.com/sharer/sharer.php?u=' . $url;
    $twitter = 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title_text;
    $linkedin = 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url;
    $whatsapp = 'https://api.whatsapp.com/send?text=' . $title_text . '%20' . $url;
    
    ?>
    <div class="social-share flex items-center gap-3">
        <?php if ($show_label) : ?>
            <span class="font-semibold text-gray-700"><?php echo esc_html($title); ?></span>
        <?php endif; ?>
        
        <a href="<?php echo $facebook; ?>" target="_blank" rel="noopener" 
           class="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition"
           aria-label="Compartilhar no Facebook">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
        </a>
        
        <a href="<?php echo $twitter; ?>" target="_blank" rel="noopener"
           class="w-10 h-10 bg-sky-500 text-white rounded-full flex items-center justify-center hover:bg-sky-600 transition"
           aria-label="Compartilhar no Twitter">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
            </svg>
        </a>
        
        <a href="<?php echo $linkedin; ?>" target="_blank" rel="noopener"
           class="w-10 h-10 bg-blue-700 text-white rounded-full flex items-center justify-center hover:bg-blue-800 transition"
           aria-label="Compartilhar no LinkedIn">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
            </svg>
        </a>
        
        <a href="<?php echo $whatsapp; ?>" target="_blank" rel="noopener"
           class="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center hover:bg-green-600 transition"
           aria-label="Compartilhar no WhatsApp">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.652a11.944 11.944 0 005.699 1.448h.005c6.555 0 11.89-5.335 11.893-11.893a11.802 11.802 0 00-3.468-8.413z"/>
            </svg>
        </a>
    </div>
    <?php
}

